import java.util.Scanner;

public class BmiTest {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        // Yalnızca bir kişinin verisini alıp BMI hesaplamak
        System.out.println("---ENTER PERSON 1'S VALUES---");
        System.out.print("Enter name, age, weight, height: (as comma separated) ");
        String inputData = input.nextLine();

        // Girdi virgülle ayrılacak
        String[] data = inputData.split(",");  // Split based on commas

        // Girdi verisini temizle ve değişkenlere atama yap
        String name = data[0].trim();  // İsmi temizle
        int age = 0;
        double weight = 0.0;
        double height = 0.0;

        try {
            // Yaş, kilo ve boy verilerini alıp sayıya dönüştür
            age = Integer.parseInt(data[1].trim());
            weight = Double.parseDouble(data[2].trim());
            height = Double.parseDouble(data[3].trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid number format! Please make sure you enter valid numbers.");
            return;  // Hata durumunda programı sonlandır
        }

        // Bmi nesnesi oluştur
        Bmi bmi = new Bmi(name, age, weight, height);

        // BMI sonucunu yazdır
        System.out.println("** The BMI result for " + bmi.getName() + " ( Age: " + bmi.getAge() + 
                           " Weight: " + bmi.getWeight() + " Height: " + bmi.getHeight() + ") is " + bmi.getStatus());
        
        // Program sonlanacak
        System.exit(0);
    }
}
